# Smart Course Management System - MERN

College-level Course Management System built with:
- React + Vite
- Node.js + Express
- MongoDB + Mongoose
- Plain CSS

## Features
- Student registration
- Login and logout (simple session state; no JWT/authorization)
- Course listing and details
- Course enrollment
- Student dashboard
- Assignment list and submission
- Quiz with automatic score calculation
- Progress display
- Profile page
- Course search

## Requirements
- Node.js 18+
- MongoDB running locally or MongoDB Atlas

## Setup

### Backend
```bash
cd backend
npm install
copy .env.example .env
npm run dev
```

For Linux/macOS:
```bash
cp .env.example .env
```

### Frontend
Open another terminal:
```bash
cd frontend
npm install
npm run dev
```

Open the URL shown by Vite.

## MongoDB
Default database:
`mongodb://127.0.0.1:27017/course_management`

Change `MONGO_URI` in backend/.env if using MongoDB Atlas.

## Note
This project intentionally does not use JWT, OAuth, role-based authorization, or protected routes. Login checks the submitted credentials against MongoDB and stores the logged-in user's basic data in browser localStorage. For a production application, passwords should never be stored in plain text and proper authentication should be implemented.
